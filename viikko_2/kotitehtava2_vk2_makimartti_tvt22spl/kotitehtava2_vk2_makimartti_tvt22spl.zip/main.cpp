#include <iostream>
#include "game.h"

using namespace std;

int main()
{   
    game gameObject (10);
    gameObject.play();
    return 0;
}
